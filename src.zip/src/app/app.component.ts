import { Component } from '@angular/core';

@Component({
  selector: 'pm-products',
  template: `<h1>Hello {{name}}</h1>`
})
export class AppComponent { name = 'Welcome  Angular 2 In Cg'; }
