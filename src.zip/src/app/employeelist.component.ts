import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-products',
  templateUrl: `./product-list.component.html`,
  styleUrls: [`./product-list.component.css`]
})
export class EmployeeListComponent implements OnInit{ 
    
    id:number;
    name:string;
    salary:number;
    department:string;    

   employees: any[] = [
    
    {
            "employeeId":2,
            "employeeName": "Garden Cart",
            "employeeSalary": "GDN-0023",
            "employeeDept": "March 18 2016",
    },
    {
            "productId":5,
            "productName": "Hammer",
            "productCode": "TBX-0048",
            "releaseDate": "May 21 2016",
            "description": "Curved claw steel hammer",
            "price": 8.9,
            "starRating": 4.8
    }
           
     
    ];
    
    ngOnInit():void{
        console.log("This is called");
    }
    
   
    
    toggleImage():void{
       alert(document.getElementById("aid"))
    }



}
